<?php
namespace App\Design_Pattern;

use App\Design_Pattern\DesignPatternInterface;
use Illuminate\Http\Request;

abstract class SubjectChecker implements DesignPatternInterface{
    protected $next;

    public function setNext(DesignPatternInterface $next)
    {
        $this->next = $next;
    }

    public function next($request)
    {
        if ($this->next) {
            return $this->next->check($request);
        }
    }
}
