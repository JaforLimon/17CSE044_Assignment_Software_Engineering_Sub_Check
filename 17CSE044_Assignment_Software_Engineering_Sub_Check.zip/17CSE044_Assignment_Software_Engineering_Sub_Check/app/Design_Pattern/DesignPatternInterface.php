<?php
namespace App\Design_Pattern;

use Illuminate\Http\Request;

interface DesignPatternInterface{
    public function setNext(DesignPatternInterface $checker);
    public function check(Request $request);
}
