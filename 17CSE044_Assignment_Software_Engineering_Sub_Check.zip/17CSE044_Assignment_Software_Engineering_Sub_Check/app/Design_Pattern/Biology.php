<?php
namespace App\Design_Pattern;

use Illuminate\Http\Request;
use App\Design_Pattern\SubjectChecker;
class Biology extends SubjectChecker
{

    public function check($request=null)
    {
        if( $request->hsc_biology && $request->biology_score >= 6){
            info('got Biology!');
            if(!empty($request['subjects']))
                $request->merge(['subjects'=> array_merge($request['subjects'],["Biology"])]);
            else
                $request->merge(['subjects'=>["Biology"]]);
        }

        return $this->next($request);
    }
}
