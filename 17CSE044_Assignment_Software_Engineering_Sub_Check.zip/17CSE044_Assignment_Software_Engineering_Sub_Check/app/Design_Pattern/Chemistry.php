<?php
namespace App\Design_Pattern;

use Illuminate\Http\Request;
use App\Design_Pattern\SubjectChecker;
class Chemistry extends SubjectChecker
{

    public function check($request=null)
    {
        if( $request->chemistry_score >= 6){
            info('got Chemistry!');
            if(!empty($request['subjects']))
                $request->merge(['subjects'=> array_merge($request['subjects'],["Chemistry"])]);
            else
                $request->merge(['subjects'=>["Chemistry"]]);
        }

        return $this->next($request);
    }
}
