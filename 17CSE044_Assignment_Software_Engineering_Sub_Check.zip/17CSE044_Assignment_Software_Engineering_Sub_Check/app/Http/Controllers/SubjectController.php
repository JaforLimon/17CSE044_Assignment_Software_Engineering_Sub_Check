<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Design_Pattern\Math;
use App\Design_Pattern\Physics;
use App\Design_Pattern\CSE;
use App\Design_Pattern\BCBT;
use App\Design_Pattern\Biology;
use App\Design_Pattern\Chemistry;
use App\Design_Pattern\CSDM;
use App\Design_Pattern\SES;
use App\Design_Pattern\Statistics;
use App\Design_Pattern\GM;
class SubjectController extends Controller
{


     public function checkSubject(Request $request)
     {



        $validator = Validator::make($request->all(),[
            'hsc_math' => 'required|boolean',
            'hsc_biology' => 'required|boolean',
            'math_score' => 'required|numeric',
            'physics_score' => 'required|numeric',
            'chemistry_score' => 'required|numeric',
            'biology_score' => 'required|numeric',
        ]);
        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }
        $math = new Math();
        $physics = new Physics();
        $cse = new CSE();
        $biochemistry_biotechnology = new BCBT();
        $biology = new Biology();
        $chemistry = new Chemistry();
        $coastal_science_disaster_management = new CSDM();
        $soil_environment_sciences = new SES();
        $statistics = new Statistics();
        $geology_mining = new GM();

        try{
            $math->setNext($physics);
            $physics->setNext($cse);
            $cse->setNext($biochemistry_biotechnology);
            $biochemistry_biotechnology->setNext($biology);
            $biology->setNext($chemistry);
            $chemistry->setNext($coastal_science_disaster_management);
            $coastal_science_disaster_management->setNext($soil_environment_sciences);
            $soil_environment_sciences->setNext($statistics);
            $statistics->setNext($geology_mining);


            $math->check($request);
        }catch (\Exception $exception){
            
            return response()->json([
                'success' => false,
                'message' => 'An error occured \n'.$exception
            ], 200);
        }

        if(count($request['subjects'])==0){
            return response()->json([
                'success' => false,
                'message' => "Eligible for no subject, Sorry. Better luck next time!",
            ], 200);
        }
        if (count($request['subjects'])==1) {
            return response()->json([
                'success' => true,
                'subjects' => $request['subjects'],
            ], 200);
        }

        return response()->json([
            'success' => true,
            'message' => "Eligible Subjects for 'A' unit of University of Barishal.",
            'subjects' => $request['subjects'],

        ], 200);
     }
}
